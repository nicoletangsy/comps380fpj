package edu.ouhk.comps380f.lecture02example;

import java.io.*;
import java.util.Date;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet(name = "anotherHelloServlet", urlPatterns = {"/greeting2","/salutation2","/wazzup2"})
public class HelloServlet2 extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        Date today = new Date();
        out.println("<!DOCTYPE html><html><body>");
        out.println("<h1>It is now: " + today + "</h1>");
        out.println("</body></html>");
    }
}